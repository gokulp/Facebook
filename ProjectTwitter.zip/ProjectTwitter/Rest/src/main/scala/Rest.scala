import spray.routing.SimpleRoutingApp
import spray.routing._
import akka.pattern._
import akka.pattern.AskTimeoutException
import spray.httpx.marshalling.ToResponseMarshallable.isMarshallable
import spray.routing.Directive.pimpApply
import spray.routing.directives.ParamDefMagnet.apply
import akka.actor._
import scala.concurrent.duration._
import akka.util._
import messages.mymessages._

/*sealed trait messages
case class Initiate(noOfUsers:Int) extends messages
case class MakeUserId(from:Int, end:Int) extends messages
case class sendmytweet(message:String,myid:Int) extends messages*/
//case class tweetstarts(message:String,myid:Int)

object Rest extends App with SimpleRoutingApp{

	import system.dispatcher

	implicit val system= ActorSystem("RestAPI")
	implicit val timeout = Timeout(3.seconds)
	var myaddress = args(0)
	var mainserveraddress = args(1)
	var mainserver = system.actorFor("akka.tcp://TwitterServer@" + mainserveraddress + ":8700/user/servermaster/serverworker")//*
	println(mainserver.path)

	//val users = Global.userdata
	startServer(interface = myaddress, port = 2552){
		post{
			path("tweetstarts"){
				parameter("message","userid".as[Int]){
					(message,userid) =>
					println("TweetDone"+message)
					mainserver ! tweetstarts(message,userid)
					
					complete{
						"Posted"
					}
				}
			}
		} ~
		//editing started latest
                post{
                        path("retweet"){
                                parameter("message","userid".as[Int]){
                                        (message,userid) =>
                                        println("RetweetDone"+message)
                                        mainserver ! tweetstarts(message,userid)
                                        
                                        complete{
                                                "Posted"
                                        }
                                }
                        }
                } ~
        get{
        	path("getUserTweets"){
        		parameter("userid".as[Int]){
        			(userid) =>
        			complete{
        				//"Posted"
        				(mainserver ? sendmytweet("Tweets",userid)).recover {
        					case ex: AskTimeoutException => { "Could not receive tweets"  }
        				}
        			.mapTo[String]
        			}
        		}
        	}
        } ~
        get{
        	path("getFollowers"){
        		parameter("userid".as[Int]){
        			(userid) =>
        			complete{
        				//"Posted"
        				(mainserver ? sendmytweet("Followers",userid)).recover {
        					case ex: AskTimeoutException => { "Could not receive followers list"  }
        				}
        			.mapTo[String]
        			}
        		}
        	}
        } ~
        get{
              path("getMentions") {
                parameter("userid".as[Int]){
                        (userid) =>
                        complete{
                                (mainserver ? sendmytweet("Mentions",userid)).recover {
                                        case ex: AskTimeoutException => { "Could not receive mention feed for this user"}
                                }
                                .mapTo[String]
                        }
                }
              }       
        } ~
        get{
              path("getEvent") {
                parameter("message"){
                        (message) =>
                        complete{
                                (mainserver ? sendmytweet(message, 11 )).recover {
                                        case ex: AskTimeoutException => { "Could not receive feed for this event"}
                                }
                                .mapTo[String]
                        }
                }
              }       
        }

	}
}