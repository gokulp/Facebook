import akka.actor._ 					//import akka dependencies
import scala.util.Random				// dependencies for random values generation
import scala.concurrent.duration._
import java.util.concurrent.TimeUnit
import akka.routing.RoundRobinRouter
import com.typesafe.config.ConfigFactory
import scala.concurrent.ExecutionContext.Implicits.global
import scala.collection.mutable.ArrayBuffer
import org.json4s.native.Serialization
import org.json4s.native.Serialization._
import org.json4s.ShortTypeHints
import java.util.ArrayList
import java.util.Collections
import messages.mymessages._
/*sealed trait messages
case class Initiate(noOfUsers:Int) extends messages
case class MakeUserId(from:Int, end:Int) extends messages
case class sendmytweet(message:String,myid:Int) extends messages
case class tweetstarts(message:String,myid:Int) extends messages
*/
object Server{
	def main(args: Array[String]) {
		if (args.length != 2) {
	      	println("No Argument(s)! Error Mode:")
       //Default mode
    	}
		var scalability = args(1).toInt
		Global.noOfMachines = args(0).toInt
		val config = ConfigFactory.parseString("akka.remote.netty.tcp.port=8700").withFallback(ConfigFactory.load()).resolve
		val system = ActorSystem("TwitterServer",config)
		System.setProperty("java.net.preferIPV4Stack","true")
		val servermaster = system.actorOf(Props(new ServerMaster()), name = "servermaster")
		println(servermaster.path)
		//var noOfUsers=1000
	}

	
	

	class ServerMaster() extends Actor{
	
		var machinecounter = 0
		var i = 0
		var temp  = 0
		var r = Random
		var a = new Array[Int](Global.total)
		var from = 0
		var end = 0
		
		var machineaddress= new Array[ActorRef](Global.noOfMachines)
		val serverworker = context.actorOf(Props[ServerWorker].withRouter(RoundRobinRouter(6)), name = "serverworker")


	def Stats():Array[Double]={
    
      var percent=Array(2.09,12.82,23.56,32.73,40.18,46.17,51.02,55.03,58.40,61.29,63.77,65.97,67.90,69.62,71.18,72.57,73.83,74.98,76.03,93.68,96.43,97.47,98.03,98.17,98.90)
      var key:Array[Double]=new Array[Double](25)
      for(i<-0 to 24){
        key(i)=(percent(i)*Global.total*.01) 
      }
      return key

    }

    def relation()={
 
      var stats= Stats()
      var nooffollowers=Array(0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,100,200,300,400,500,1000)
      var count=0
      var from =0
      var end=nooffollowers(count)
      var randomfound=0
      var r=Random
      var totusers=Global.total
      
      for (i<- 0 to Global.userdata.size-1){
        
        if(i>stats(count)){
          
          if(count>=24)
            end=50000
          else{
            from=end
            count=count+1
            end=nooffollowers(count)
          }  
        }

        if(i<=stats(count)&&(count < 19)){
          
          for(j<- 0 to nooffollowers(count)-1){
            randomfound=r.nextInt(totusers)
            Global.userdata(i).followers+=randomfound 
            Global.userdata(randomfound).following+=Global.userdata(i).userid
          }
          
        }

        if(i<=stats(count)&&(count>=19)||(end==50000)){
         
          val range=from to end
          var rand=range(r.nextInt(range.length))
          for(j<-0 to rand-1){//zero followers
            randomfound=r.nextInt(totusers)
            Global.userdata(i).followers+=randomfound 
            Global.userdata(randomfound).following+=Global.userdata(i).userid
          } 

        }

      }

    }
		

		def receive = {

			case Initiate(noOfUsers) => {
				
				machineaddress(machinecounter)=sender
				println("Client Machine: "+machinecounter+1+" contacted the Server" )
				Global.total=noOfUsers*Global.noOfMachines
				machinecounter=machinecounter+1 
		
				
				if(machinecounter==Global.noOfMachines){
					
					Global.userdata=new Array[UserInfo](Global.total)				    // object of the userinfo class	
					for(i<-0 to Global.total-1){								// creating user ids 
						Global.userdata(i)=new UserInfo(i)
						println("User ids Created by server"+Global.userdata(i).userid)
					}
					relation()
					/*for (i <- 0 to Global.total-1){								// assiging random followers to the users
						for (j <- 0 to 5){
							temp = r.nextInt(Global.total)
							Global.userdata(i).followers += temp					// adding to the set of followers
							Global.userdata(temp).following += i 					// adding to the set of following
						}
					}*/
					/*for(i<-0 to Global.total-1){
						println(Global.userdata(i).followers.size)
					}*/


					for(i<-0 to machineaddress.length-1){
						println("Server Master sending ids to Client Machine: "+i)
						from = end
						end += noOfUsers
						machineaddress(i)! MakeUserId(from,end)
					}

					//Scheduler

					 context.system.scheduler.schedule(Duration.create(2, TimeUnit.SECONDS),
            			Duration.create(1, TimeUnit.SECONDS)) {
			          /*for(i<- 0 to Global.userdata.size-1){
			                println("User" +i+"\n---------------------------")

			                for(j<-0 to Global.userdata(i).myMessages.size-1){
			                  println(Global.userdata(i).myMessages(j))
			                }
			                println("\n---------------------------")
			            }*/
			            println("Message Processed in 60 sec: "+Global.msgstart)//*********
			            Global.msgstart=0
			           	

					}
					context.system.scheduler.scheduleOnce(65.seconds) {

			            for(i<-0 until machineaddress.size)
			           	machineaddress(i) ! "terminate"
			            
			            context.system.shutdown
			        }

				}
			}	


			/*case sendmytweet(message,myid) =>{
				println(message + "for" + myid)
				println("\n---------------------------")
                for(j<-0 to Global.userdata(myid).myMessages.size-1){
			                  println(Global.userdata(myid).myMessages(j))
			                }
				println("\n---------------------------")

			} */
		}

	}

	class ServerWorker extends Actor{
        
        private implicit val formats = Serialization.formats(ShortTypeHints(List(classOf[String])))
        /*def userDetails(array:Array[String]):String ={
            var a : String = "" //new ArrayList[String]()
            for(j<-0 to array.length-1){
                   if( array(j) != null )        	 
			           a = a + " " + array(j)
			  }	
			  //writePretty(list)
			  println(a)
        }*/
		def receive = {
			case tweetstarts(message,myid)=>{
				Global.userdata(myid).msgstore(message)
				for(x<- Global.userdata(myid).followers)
				Global.userdata(x).msgstore(message)
				Global.msgstart=Global.msgstart+1

			}
			case sendmytweet(message,myid) =>{
				/*println(message + "for" + myid)
				println("\n---------------------------")*/
				
				var a = ""
				if ( message == "Tweets") {
                for(j<-0 to Global.userdata(myid).myMessages.size-1){
                	       a = "Tweets for user"+ myid + "\n---------------------------------------\n"
			               if( Global.userdata(myid).myMessages(j) != null )
			               a = a + "\n" + Global.userdata(myid).myMessages(j)
                                                  
			       }
			       a = a + "\n--------------------------------------------"
			       println(a)
			       } else if (message == "Followers"){
			       	a = "Followers for user"+ myid + "\n--------------------------------------------\n"
			       	for(j<-0 to Global.userdata(myid).followers.size-1){
			               //if( Global.userdata(myid).followers(j) != "" )
			                  a = a + "\n" + Global.userdata(myid).followers(j)
                           
                           //println(a)
			       }
			       a = a + "\n--------------------------------------------"
                   println(a)
                   if(a == null)
                       a = a + "\n No Followers for this user"
			       } else if (message == "Mentions"){
			       	a = "Mentions feed for user" + myid + "\n-----------------------------------------\n"
			       	for(j<-0 to Global.userdata(myid).myMessages.size-1){
			       		if(Global.userdata(myid).myMessages(j) contains ("@"+myid))
			       		  a = a + "\n" + Global.userdata(myid).myMessages(j)
			           }
			           a = a + "\n--------------------------------------------"
			           println(a)
			       } else {
			       	 a = " Event feed for " + message  + "\n-----------------------------------------"
			       	 for(i<- 0 to Global.userdata.size-1){
			       	 for(j<-0 to Global.userdata(i).myMessages.size-1){
			       		if( Global.userdata(i).myMessages(j) contains ("*"+message)){
			       		
			       		  a = a + "\n" + Global.userdata(i).myMessages(j)
			       		
			           }
			       }
			       }
			           a = a + "\n--------------------------------------------"
			           println(a)
			       }
				//println("\n---------------------------")
                
                sender ! a   //Global.userdata(myid).myMessages(0)

			} 
		} 
	}

	class UserInfo(id:Int){													// class for users information
		var userid : Int = id
		var following =ArrayBuffer.empty[Int]
		var followers =ArrayBuffer.empty[Int]
		var myMessages =new Array[String](100)
		var msgcount = -1

		def msgstore(message:String)={
			if(msgcount==99)
			  msgcount = -1
			msgcount=msgcount+1
			myMessages(msgcount)=message
		}
	}

	object Global {
		var noOfMachines=0
		var userdata:Array[UserInfo]= _
		var total=0
		var msgstart=0
	}
	
}