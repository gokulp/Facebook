import akka.actor._
import scala.util.Random
import scala.concurrent.duration._
import java.util.concurrent.TimeUnit
import scala.collection.mutable.HashMap
import java.util.ArrayList
import java.util.Collections
import spray.http._
import spray.client.pipelining._
import akka.actor.ActorSystem


/*sealed trait messages
case class Initiate(noOfUsers:Int) extends messages
case class MakeUserId(from:Int, end:Int) extends messages
case class sendmytweet(message:String,myid:Int) extends messages
case class tweetstarts(message:String,myid:Int) extends messages*/


object Client{
	implicit val system = ActorSystem("TwitterClient")
	import system.dispatcher
	import messages.mymessages._
	var pipeline = sendReceive

	def main(args: Array[String]) {
		if (args.length !=3) {
	      	println("No Argument(s)! Error Mode:")
       //Default mode
    	}
    
		

		var ipaddress= args(0)
		Global.restAddress+= args(1)+ ":2552/"	
		println(Global.restAddress)				//read argument 1 as ipaddress
		var scalability = args(2).toInt;            //read argument 2 as scalability
		var noOfTotalUsers : Int = 1000000
		var noOfUsers = ( scalability * noOfTotalUsers ) / 100
		//val result = pipeline(Get(ipaddress + "server"))
		System.setProperty("java.net.preferIPV4Stack","true")
		
		val master = system.actorOf(Props(new ClientMaster(noOfUsers,ipaddress)),name="master")
		println("Hello! How are you???")
		master ! "StartMe"
	}
	class ClientMaster(noOfUsers:Int,ipaddress:String) extends Actor {

		var myusers:Array[ActorRef] = new Array[ActorRef](noOfUsers)
		var begin:Long = 0
		var finish:Long = 0
		var servermaster = context.actorFor("akka.tcp://TwitterServer@"+ ipaddress +":8700/user/servermaster")
		def receive = {

			case "StartMe" => {
				println("heloooooooo")
				println("Server Master" +servermaster)
				servermaster ! Initiate(noOfUsers)
			}
			case MakeUserId(from,end)=> {
				println("Received my id's")
				for(i <- 0 to noOfUsers-1){
					myusers(i) = system.actorOf(Props(new ClientWorker(from+i,servermaster,ipaddress)),name="clientworker"+(from+i))
					myusers(i) ! "Start"
				}
			}
			case "terminate"=>{
				context.system.shutdown
			}


			}

		}

		
	

	class ClientWorker(uid:Int,servermaster:ActorRef,ipaddress:String) extends Actor{
		var userid:Int=uid
		var serverworker = context.actorFor("akka.tcp://TwitterServer@"+ ipaddress +":8700/user/servermaster/serverworker")
		def receive = {
			case "Start" =>{
				println("User id s : "+userid)

				context.system.scheduler.schedule(Duration.create(600, TimeUnit.MILLISECONDS),
         		 Duration.create(1, TimeUnit.SECONDS)) {
					var r = Random
					var stringindex = r.nextInt(100)

					//serverworker ! tweetstarts(Global.tweetarray(stringindex),userid)
					println("Sending http request...")
					pipeline(Post(Global.restAddress + "tweetstarts?message=" + Global.tweetarray(stringindex) + "&userid=" + userid ))

				}

				//editing from here
				context.system.scheduler.schedule(Duration.create(6000, TimeUnit.MILLISECONDS),
         		 Duration.create(10, TimeUnit.SECONDS)) {
					var r = Random
					var stringindex = r.nextInt(100)

					//serverworker ! tweetstarts(Global.tweetarray(stringindex),userid)
					println("Retweet...")
					pipeline(Post(Global.restAddress + "retweet?message=" + (Global.tweetarray(stringindex)+"RT@"+userid) + "&userid=" + userid ))

				}
			}

			case "tweets" =>{
				//pipeline(Post(Global.restAddress + "sendmytweet?message=" + userid + "&userid=" + Global.tweetarray(stringindex) + "&tweetid=" + sendingTweetId))

			}
		}
	}

	object Global{
		var tweetarray = new Array[String](100)
		var i=0
		var restAddress ="http://"
		var filename = "/Users/sakshikakkar/Desktop/stwitter/myfile.txt"
		for(line <- scala.io.Source.fromFile(filename).getLines()){
			tweetarray(i) = line
			//println(tweetarray(i))
  			i+=1
		}
	}
}